const { TOKEN_PROGRAM_ID } = require("@solana/spl-token");
const { Keypair, Transaction, SystemProgram, LAMPORTS_PER_SOL, Connection, PublicKey, clusterApiUrl, sendAndConfirmTransaction } = require("@solana/web3.js");
const mysql = require('mysql2');
const mysqlpromise = require('mysql2/promise');
const crypto = require('crypto');
const express = require('express');
const { request, response } = require('express');
const { exit } = require("process");
const https = require('https');
const fs = require('fs');
var cors = require('cors')

const app = express();
app.use(cors());
app.use(express.json());

const encrypted = require("./readencrypted");

global.Important = encrypted.Read('./Important.txt');

const func = require("./UserRegister");


const options = {
  key: fs.readFileSync('fulbostars.com.key'),
  cert: fs.readFileSync('fulbostars.com.crt')
};

var server = https.createServer(options, app);

llamadasfuncion = {
    "UserRegister"  : func.UserRegister,
    "ValidateUser"  : func.ValidateUser,
    "LoginPass"     : func.LoginPass,
    "GetInformation": func.GetInformation,
    "ChangePassword": func.ChangePassword,
    "ChangeMobil"   : func.ChangeMobil,
    "ValidateMobil" : func.ValidateMobil
}

accionesposibles = {
    "UserRegister"   : ["user", "password", "wallet","avatar"],
    "ValidateUser"   : ["user", "code"],
    "LoginPass"      : ["user", "password"],
    "GetInformation" : ["token"],
    "ChangePassword" : ["user", "oldpassword", "newpassword"],
    "ChangeMobil"    : ["token" , "number"],
    "ValidateMobil"  : ["token", "code"]
}
// chequeamos que existen todas las llamadas a funcion

if(Object.keys(accionesposibles).length != Object.keys(llamadasfuncion).length){
    console.error("1No se encontro la funcion para la accion");
    exit(1);
}

for(var key in accionesposibles){
    console.log(key);
    if(!(key in llamadasfuncion)){
        console.error("1No se encontro la funcion para la accion");
        exit(1);
    }
}

//definimos los nombres de las llamadas
//ahora le pongo el mismo valor pero hay que cambiarlo

app.post('/api', (request, response) => {
    const data = request.body
    var mess='';
    var flag=true;
    console.log(data);
    if (data === undefined) { 
        mess='Something is missing' ;
        response.status(400).json({ error: mess});
    }

// revisamos que existan los campos action, data, who, sign

    else if(!data.action || !data.data || !data.who || !data.sign){ 
        mess='Something is missing' ;
        response.status(400).json({ error: mess}) 
    }

// revisamos que la accion se encuentre definida
    else if(!(data.action in accionesposibles)) {
        mess='Action Unknown';
        return response.status(400).json({ error: mess}) 
    }

// ahora revisamos que los datos tengan todos los campos requeridos para la accion
    else if(Object.keys(data.data).length != accionesposibles[data.action].length){
        mess='Not all data';
        response.status(400).json({ error: mess}) 
    }

    else{
        for(var i in accionesposibles[data.action]){
            console.log(accionesposibles[data.action][i]);
            if(!(accionesposibles[data.action][i] in data.data)){
                mess='Not all data in data';
                response.status(400).json({ error: mess})
                flag=false; 
                break;
            }
        }
        if(flag){
    // Ahora seleccionamos la funcion 
            mess="llamando a "+data.action;
            llamadasfuncion[data.action](response,data.data,data.who,data.sign);
        }
    } 

    console.log(mess);
//   response.status(200).json(true);
});

app.get('/author', (request, response) => {
    if(Important.Author == undefined){
        console.log("Intento de conexion por metodo o ruta incorrecto");
        response.status(404).json({ error: 'incorrect path' });
    }else{
        response.status(200).send(Important.Author);
    }
});

app.use((request, response) => {
    console.log("Intento de conexion por metodo o ruta incorrecto");
    response.status(404).json({ error: 'incorrect path' });
})

const PORT = process.env.PORT || 3000
//app.listen(PORT, () => {
//    console.log(`Server running on port ${PORT}`)
//})

server.listen(PORT, () => {
  console.log("server starting on port : " + PORT)
});

let keypair = Keypair.fromSecretKey(Uint8Array.from(Important.secretKey));

let TokenAccount = new PublicKey("2BN4GxbBGcNiPWvSDtvWw7jFk4XV7LVFHY4PETUyWrGg");

let connection = new Connection(clusterApiUrl('devnet'));

async function ActualizarRegistroSolana() {
    /*
        databasecon.query("select wallet from usuarios order by id desc limit 1", (err, result) => {
            if (err) throw err;
            console.log(result);
            console.log("firma "+ result[0].wallet);
            pepe=result[0].wallet;
        });
        console.log("out "+pepe);
    */
    while (true) {
        ultimafirma = await query("select firma from transacciones order by id desc limit 1");
        console.log(typeof ultimafirma[0]);
        var signatures;

        if (typeof ultimafirma[0] !== "undefined") {
            console.log("continuando desde " + ultimafirma[0].firma);
            signatures = await connection.getConfirmedSignaturesForAddress2(TokenAccount, { until: ultimafirma[0].firma });
        } else {
            console.log("arrancando de cero");
            signatures = await connection.getConfirmedSignaturesForAddress2(TokenAccount);
        }

        firma:
        for (var i = signatures.length - 1; i >= 0; i--) {
            var sig = signatures[i];
            console.log("Firma " + sig.signature);
            var transaction = await connection.getConfirmedTransaction(sig.signature);
            //    console.log(transaction);
            console.log("Firmada por " + transaction.transaction.signatures[0].publicKey.toString());


            console.log(" ");
            console.log("prebalance ");
            for (let pre of transaction.meta.preTokenBalances) {
                console.log(pre);
            }
            console.log("\npostbalance ");
            for (let post of transaction.meta.postTokenBalances) {
                console.log(post);
            }

            if (transaction.meta.postTokenBalances.length != 2) {
                //          console.log("Esta operacion no fue una transferencia!");
                continue;
            }

            //    console.log("Esta operacion fue una transferencia");
            let sender = transaction.meta.preTokenBalances[0].owner;
            let isender = transaction.meta.preTokenBalances[0].accountIndex - 1;
            if (isender == 1) {
                irec = 0;
            }
            else {
                irec = 1;
            }

            let receiver = transaction.meta.postTokenBalances[irec].owner;
            let cantidad = transaction.meta.preTokenBalances[0].uiTokenAmount.uiAmount - transaction.meta.postTokenBalances[isender].uiTokenAmount.uiAmount;

            // let receiver = transaction.meta.postTokenBalances[1].owner;
            //        var sqlusuario = await query(`select * from usuarios`);
            //        const qr=`select id from usuarios where wallet = '6nt3FL4gRbj3ygK5WRaTGF2fhz8jUjoJ1FqAMLqbQwN5'`;
            //       console.log(qr);
            //        var sqlusuario = await query(`select id from usuarios where wallet = '6nt3FL4gRbj3ygK5WRaTGF2fhz8jUjoJ1FqAMLqbQwN5'`);
            //        console.log("usuario : "+sqlusuario[0].id);
            console.log("INFO  ");
            console.log(sender);
            console.log(isender);
            console.log(cantidad);
            console.log(receiver);
            console.log("");
            var sqlusuario;
            var tipooperacion;
            if (sender === receiver)
                receiver = transaction.meta.postTokenBalances[0].owner;

            if (sender === keypair.publicKey.toString()) {
                console.log("transaccion enviada por el servidor " + sender + " a " + receiver);
                tipooperacion = 'S';
                sqlusuario = await query(`select id, tokens from usuarios where wallet = '${receiver}'`);
                /*            if(sqlusuario.length>0){
                                databasecon.query(`INSERT INTO transacciones (id_usuario, tipo, tokens, firma) VALUES (${sqlusuario[0].id}, 'S', ${cantidad}, '${sig.signature}' )`, function (err, result) { if (err) throw err; });
                                databasecon.query(`update usuarios set tokens = (tokens - ${cantidad}) where id = ${sqlusuario[0].id}`, function (err, result) { if (err) throw err; });
                            }*/
            }
            else if (receiver === keypair.publicKey.toString()) {
                sqlusuario = await query(`select id, tokens from usuarios where wallet = '${sender}'`);
                tipooperacion = 'R';
                /*            if(sqlusuario.length>0){
                                databasecon.query(`INSERT INTO transacciones (id_usuario, tipo, tokens, firma) VALUES ((select id from usuarios where wallet = '${sender}'), 'R', ${cantidad}, '${sig.signature}' )`, function (err, result) { if (err) throw err; });
                                databasecon.query(`update usuarios set tokens = (tokens + ${cantidad}) where wallet = '${sender}'`, function (err, result) { if (err) throw err; });
                            }*/
            }
            else
                console.log("ni una ni otra");

            if (sqlusuario !== undefined && sqlusuario.length > 0) {

                console.log("usuario id " + sqlusuario[0].id + " tokens " + sqlusuario[0].tokens);
                if (tipooperacion == 'R')
                    sqlusuario[0].tokens += cantidad;
                else
                    sqlusuario[0].tokens -= cantidad;
                console.log("balance " + sqlusuario[0].tokens);
                databasecon.query(`INSERT INTO transacciones (id_usuario, tipo, tokens, firma) VALUES (${sqlusuario[0].id}, '${tipooperacion}', ${cantidad}, '${sig.signature}' )`, function (err, result) { if (err) throw err; });
                databasecon.query(`update usuarios set tokens = ${sqlusuario[0].tokens} where id = ${sqlusuario[0].id}`, function (err, result) { if (err) throw err; });
            }
            else {
                console.log("usuario no registrado");
            }
            //        databasecon.query(`INSERT INTO transacciones (usuario, password, email, wallet, tokens) VALUES ('${data.data.user}','${data.data.password}','${data.data.email}','${data.data.wallet}',0)`, function (err, result) {
            //console.log(err);        

        }
        await new Promise(resolve => setTimeout(resolve, 5000));
        console.log("continuamos");
    }
    //    });

}


function query(sql) {
    // devolver una promesa
    return new Promise((resolve, reject) => {
        databasecon.query(sql, (err, rows) => {
            if (err) {
                reject(err)
            } else {
                resolve(rows)
            }
        })
    })
}
/*
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
}*/
//ActualizarRegistroSolana();

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
}

async function tests() {
    console.log("primero");
    var res = await query(`select * from usuarios`);
    console.log(res[0].usuario);
    console.log("segundo");
}

connection.onProgramAccountChange(TokenAccount,(res) =>{
    

    console.log("hola");
});
//
