const fs = require('fs');
const crypto = require('crypto');
const algorithm = 'aes-256-ctr';
var readlineSync = require('readline-sync');
const { exit } = require('process');

module.exports = {
    Read : function (file) {
        const dataread = fs.readFileSync(file, {encoding:'utf8', flag:'r'});

        var password = readlineSync.question('Please enter password: ', {hideEchoBack: true});
        key = crypto.createHash('sha256').update(String(password)).digest('base64').substr(0, 32);
        var encrypted = Buffer.from(dataread,'hex');
        // Get the iv: the first 16 bytes
        const iv = encrypted.slice(0, 16);
        // Get the rest
        encrypted = encrypted.slice(16);
        // Create a decipher
        const decipher = crypto.createDecipheriv(algorithm, key, iv);
        // Actually decrypt it
        const result = Buffer.concat([decipher.update(encrypted), decipher.final()]);
        try{
            const decrypteddata = JSON.parse(result.toString());
            return decrypteddata;
        }
        catch{
            console.log("Error en el password");
            exit(5);
        }
    }
}

