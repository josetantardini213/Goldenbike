const nodemailer = require("nodemailer");
const crypto = require('crypto');
const res = require("express/lib/response");
const mysql = require('mysql2');
const mysqlpromise = require('mysql2/promise');
var bcrypt = require('bcryptjs');
const saltRounds = 10;
var salt = bcrypt.genSaltSync(10);
const MaxCodeCount = 3;
const MaxMobileCodeCount = 3;
const MaxCodeLapse = 30;   // Maximo tiempo para aceptar el codigo en minutos
const MaxTokenLapse = 60;  // Maximo tiempo de un token en dias
const MaxTokenGenTries = 10;
const MaxSMSSend = 10 ;

//insertcard(9,4);
//buyenvolope(9,1);

function newcode() {  
    return Math.floor(
      Math.random() * 1000000 
    )
}

function connectdatabase(){
    var databasecon = mysql.createConnection({
        host: "",
        user: Important.DatabaseUser,
        password: Important.DatabasePass,
        database: Important.DatabaseName
    });

    databasecon.connect(function (err) {
        if (err) throw err;
    });
    return databasecon;
}

async function sendcode(email,code){
    const connection= await mysqlpromise.createConnection({
        host: "",
        user:     Important.DatabaseUser,
        password: Important.DatabasePass,
        database: Important.DatabaseName
    });

    let transporter = nodemailer.createTransport({
        host: Important.MailHost,
        port: 465,
        secure: true,
        auth: {
            user: Important.MailUser,
            pass: Important.MailPass
        },
        tls: {
            rejectUnauthorized: false
        }
    });


    // send mail with defined transport object
    const info=transporter.sendMail({
        from: 'no-reply@fulbostars.com', // sender address
        to: email, // list of receivers
        subject: "Verification Code", // Subject line
        html: "<b>This is your verification code "+code+" </b>", // html body
    });
    console.log("Message sent: %s", info.messageId);
}

async function newpassword(response,user,password,newpass){
    const connection= await mysqlpromise.createConnection({
        host: "",
        user:     Important.DatabaseUser,
        password: Important.DatabasePass,
        database: Important.DatabaseName
    });

    var query=`SELECT id,password,active from users where user = '${user}'`;
    var [result, fields] = await connection.execute(query);
//    console.log(result);

    if(result.length == 0){
        return response.status(409).json({error : 'Unkown User'});
    }
    else if(!result[0].active){
        return response.status(409).json({error : 'User was not activated'});
    }
    else if(! bcrypt.compareSync(password, result[0].password)){
        return response.status(409).json({error : 'Incorrect Password'});
    }
    else{
        const id=result[0].id;
        var hashpass = bcrypt.hashSync(newpass, salt);
        query=`UPDATE users SET password='${hashpass}' WHERE id=${id} `;
        [result, fields] = await connection.execute(query);
        if(result.affectedRows == 0){
            response.status(409).json({error : "Cannot Update Password"});
        }
        else{
            response.status(200).json({answer : "Updated"});
        }
    }
}

async function newtoken(response,user,password){
    const connection= await mysqlpromise.createConnection({
        host: "",
        user: Important.DatabaseUser,
        password: Important.DatabasePass,
        database: Important.DatabaseName
    });

    var query=`SELECT id,password,active from users where user = '${user}'`;
    var [result, fields] = await connection.execute(query);
    console.log(result);

    if(result.length == 0){
        return response.status(409).json({error : 'Unknown User'});
    }
    else if(!result[0].active){
        return response.status(409).json({error : 'User not Activated'});
    }
    else if(! bcrypt.compareSync(password, result[0].password)){
        return response.status(409).json({error : 'Incorrect Password'});
    }
    else{
        const id=result[0].id;
        var count=0;
        var token;
        do{
            token=crypto.randomBytes(64).toString('hex');
            query=`select id from pass where pass = "${token}"`;
            console.log(query);
            [result, fields] = await connection.execute(query);
            count++;
        }while(result.length>0 && count<MaxTokenGenTries);
        if(count==MaxTokenGenTries){
            console.log("error al generar token");
            return response.status(409).json({error : 'Cannot generate token'});
        }
        else{
            query=`insert into pass (userid,pass) values ("${id}","${token}")`;
            connection.execute(query);
            return response.status(200).json({'Token' : token});
        }
    }
}

async function getinformation(response,token){
    const connection= await mysqlpromise.createConnection({
        host: "",
        user: Important.DatabaseUser,
        password: Important.DatabasePass,
        database: Important.DatabaseName
    });

    var query=`select userid,timestampdiff(day,creationDate,now()) as lapse from pass where pass = '${token}'`;
    var [result, fields] = await connection.execute(query);

    if(result.length == 0){
        return response.status(409).json({error : 'Unknown token'});
    }
    else if(result[0].lapse>MaxTokenLapse){
        query=`delete from pass where pass = '${token}'`;
        connection.execute(query);
        return response.status(400).json({error : 'Token expired'});
    }
    else{
        const userid=result[0].userid;
        query=`select * from users where id = ${userid}`;
        [result, fields] = await connection.execute(query);
        if(result.length == 0){
            return response.status(409).json({error : 'user not match'});
        }
        else if(!(result[0].active)){
            return response.status(409).json({error : 'user inactive'});
        }
        else {
            const exp=result[0].exp;
            const tokens=result[0].tokens;
            const avatar=result[0].avatar;
            var wallet="";
            var mobile="";
            if(result[0].mobile!=null){
                mobile=result[0].mobile;
            }
            if(result[0].wallet!=null){
                wallet=result[0].wallet;
            }
            query=`select * from cards where user= ${userid}`;
            [result, fields] = await connection.execute(query);
            return response.status(200).json(
                {"Experience" : exp, "Tokens": tokens, "Avatar": avatar,"Mobile": mobile, "Wallet": wallet, result });
        }
    }
}


//Esta funcion no verifica si esta activo o existe el usuario, hacerlo antes
async function insertcard(userid,cardid){
    const connection= await mysqlpromise.createConnection({
        host: "",
        user: Important.DatabaseUser,
        password: Important.DatabasePass,
        database: Important.DatabaseName
    });

    var query=`select * from player where id = ${cardid}`;
    var [result, fields] = await connection.execute(query);
    if(result.length == 0){
        return false;
    }
    query=`insert into cards 
    (user     ,player,      accuracy,           stamina,               speed,         dexterity,             trickery) values 
    (${userid},${cardid},${result[0].accuracy},${result[0].stamina},${result[0].speed},${result[0].dexterity},${result[0].trickery})`;
    console.log(query);
    await connection.execute(query);
    return true;
}

async function buyenvolope(UserId,EnvelopeId){
    const connection= await mysqlpromise.createConnection({
        host: "",
        user: Important.DatabaseUser,
        password: Important.DatabasePass,
        database: Important.DatabaseName
    });

    var query=`select * from envelopes where id = ${EnvelopeId}`;
    var [result, fields] = await connection.execute(query);
    if(result.length == 0){
        return 0;
    }
    const nplayer=result[0].nplayers;
    console.log(result);
    const prob=[result[0].rarity1prob,result[0].rarity2prob,result[0].rarity3prob,result[0].rarity4prob];
    var totalprob=0.0;
    for(var i=0;i<4;i++){
        totalprob+=prob[i];
    }
    console.log(totalprob);
    var acumprob=[0.0,0.0,0.0,0.0];
    acumprob[0]=prob[0]/totalprob;
    for(var i=1;i<4;i++){
        acumprob[i]=acumprob[i-1]+prob[i]/totalprob;
    }
    console.log(acumprob);
    for(var np=0;np<nplayer;np++){
        const rand=Math.random();
        console.log(rand);
        var rarity=0;
        for(rarity=0;rarity<4;i++){
            if(rand<acumprob[rarity])
                break;
        }
        console.log("rarity = "+rarity);
    }
}   

function createsign(acciones,data,who,aditional=''){
    var string="";
    for(var key in acciones){
        string+=data[acciones[key]]+",";
    }
    if(aditional !== '')
        string+=aditional+",";
    string+=who+","+Important.programwho[who];
    console.log("string "+string);
    return crypto.createHash('sha256').update(string).digest('hex').toUpperCase();
}

async function changemobilnumber(response,pass,number){
    const connection= await mysqlpromise.createConnection({
        host: "",
        user: Important.DatabaseUser,
        password: Important.DatabasePass,
        database: Important.DatabaseName
    });

    var query=`SELECT id,userid from pass where pass = '${pass}'`;
    var [result, fields] = await connection.execute(query);
    console.log(result);

    if(result.length == 0){
        response.status(409).json({error : 'Unknown Token'});
    }
    else{
        const code=newcode();
        const userid=result[0].userid;
        const passid=result[0].id;
        [result, fields] = await connection.execute(`select mobilecodesent from users where id=${userid}`);
        const count=result[0].mobilecodesent;
        if(count>MaxSMSSend){
            response.status(404).json({error : "Max tries Reached"});
        }
        else{
            query=`select pass from mobilecode where userid=${userid}`;
            [result, fields] = await connection.execute(query);
            if(result.length == 0){
                query=`insert into mobilecode (userid,code,pass,newnumber) VALUES (${userid},${code},${passid},${number})`;
            }
            else{
                query = `update mobilecode set code=${code}, pass=${passid}, newnumber=${number}, count=0 where userid=${userid}`;
            }
            try{
                [result, fields] = await connection.execute(query);
            } catch {
                response.status(404).json({error : "Code generated Error"});    
            }
            if(result.affectedRows == 1){
                //Esta linea debe reemplazarse cuando este la funcion de enviar sms
                query=`update users set mobilecodesent = mobilecodesent + 1 where id=${userid} `;
                try{
                    [result, fields] = await connection.execute(query);
                } catch {
                    console.log("error updating mobilecodesent");
                    response.status(200).json({"code" : code});
                }
                response.status(200).json({"code" : code});
            }
        }
    }
}

async function validatemobilnumber(response,pass,code){
    const connection= await mysqlpromise.createConnection({
        host: "",
        user: Important.DatabaseUser,
        password: Important.DatabasePass,
        database: Important.DatabaseName
    });

    var query=`SELECT userid,code,newnumber,pass from mobilecode where pass = (SELECT id from pass where pass = '${pass}')`;
    var [result, fields] = await connection.execute(query);

    if(result.length == 0){
        response.status(404).json({error : 'No registered Code was Found'});
    }
    else if(code==result[0].code){
        const number=result[0].newnumber;
        const userid=result[0].userid;
        const passtoken=result[0].pass;
        query=`DELETE FROM mobilecode where pass = '${passtoken}'`;
        await connection.execute(query);
        query=`UPDATE users set mobile='${number}', mobileactive=1 where id=${userid}`
        [result, fields]=await connection.execute(query);
        if(result.affectedRows == 0){
            response.status(402).json({error : "Cannot updated the number, sory"});    
        }
        else{
            //Esta linea debe reemplazarse cuando este la funcion de enviar sms
            response.status(200).json({answer : "Updated"});
        }
    }
    else{
        const pass= result[0].pass;
        query=`update mobilecode set count = count + 1 where pass= '${pass}' `;
        await connection.execute(query);
        query=`select count from mobilecode where pass = '${pass}'`;
        [result, fields] = await connection.execute(query);
        if(result.length > 0 && result[0].count>=MaxMobileCodeCount){
            connection.execute(`delete from mobilecode where  pass= '${pass}'`);
            response.status(666).json({error: 'Max Tries Reached, Code Deleted!'});
        }
        else{
            response.status(409).json({error: "Code doesn't Match"});
        }
    }
}


async function validateuser(response,user,code){
    const connection= await mysqlpromise.createConnection({
        host: "",
        user: Important.DatabaseUser,
        password: Important.DatabasePass,
        database: Important.DatabaseName
    });

    var query=`select code,timestampdiff(minute,creationDate,now()) as lapse from code where userid = (select id from users where user = '${user}')`;
    var [result, fields] = await connection.execute(query);
    if(result.length == 0){
        response.status(409).json({error : 'User Unknown or Without Code'});
    }
    const dbcode =result[0].code;
    const dblapse = result[0].lapse;
    if(dblapse > MaxCodeLapse){
        connection.execute(`delete from code where code = '${dbcode}'`);
        response.status(429).json({error: 'Expired Code'});
    }
    else{
        if(dbcode == code){
            connection.execute(`delete from code where code = '${code}'`);
            connection.execute(`update users set active = true where user = '${user}'`);
            response.status(200).json({answer : "Activated"});
        }
        else{
            query=`update code set count = count + 1 where code = '${dbcode}'`;
            await connection.execute(query);
            query=`select count from code where code = '${dbcode}'`;
            [result, fields] = await connection.execute(query);
            if(result.length > 0 && result[0].count>=MaxCodeCount){
                connection.execute(`delete from code where code = '${dbcode}'`);
                connection.execute(`delete from users where user = '${user}'`);
                response.status(666).json({error: 'Max Tries Reached, User Deleted!'});
            }
            else{
                response.status(404).json({error: 'Incorrect Code'});
            }
        }
    }
}



module.exports = {
    UserRegister : function (response,data,who,sign){
        console.log("User Register");

        //only web/php
        if(who != Important.Programwho[0]){response.status(400).json({ error: 'Who are you?'});}
        else{
            const hash=createsign(accionesposibles["UserRegister"],data,who);
            console.log(hash);

            if(hash == sign){
                const databasecon=connectdatabase();
                var hashpass = bcrypt.hashSync(data.password, salt);
                var query;
                if(data.wallet == ''){
                    query=`INSERT INTO users (user, password, avatar) VALUES ('${data.user}','${hashpass}','${data.avatar}')`;
                }
                else{
                    query=`INSERT INTO users (user, password, wallet, avatar) VALUES ('${data.user}','${hashpass}','${data.wallet}','${data.avatar}')`;
                }
                console.log(query);
                databasecon.query(query, function (err, result) {
                    if (err){
                        console.log("Error al insertar "+data);
                        console.log(err);
                        if(/key \'users.user/.test(err)){
                            response.status(409).json({error : "User already registered"});
                        }
                        else if(/key \'users.wallet/.test(err)){
                            response.status(409).json({error : "Wallet already registered"});
                        }
                        else{
                            response.status(409).json({error : "Other error"});
                        }
                    }
                    else{
                        const code=newcode();
                        const query=`INSERT INTO code (userid, code) VALUES ('${result.insertId}','${code}')`;
                        databasecon.query(query, function (err, result) {
                            if(err){
                                console.log("Error al insertar codigo "+code);
                                response.status(409).json(err.sqlMessage);
                            }
                            else{
                                sendcode(data.user,code);
                                response.status(200).send("UserRegister true");
                            }
                        });
                    }
                });
            }
            else 
                response.status(404).json({ error: 'Sign Error'});
        }
    },

    ValidateUser : function (response,data,who,sign){
        console.log("ValidateUser");
        //only web/php
        if(who != Important.Programwho[0]){response.status(400).json({ error: 'Who are you?'});}
        else if(data.code == ''){
            response.status(400).json({ error: 'Empty code'});
        }
        else{
            const hash=createsign(accionesposibles["ValidateUser"],data,who);
            console.log(hash);
            if(hash == sign){
                validateuser(response,data.user,data.code).catch(error=>console.log(error));
            }
            else{
                response.status(404).json({ error: 'Sign Error'});
            }
        }
    },

    LoginPass : function (response,data,who,sign){
        console.log("Login");
        //every interface
        if(!(who.toString() in Important.programwho)){response.status(400).json({ error: 'Who are you?'});}
        else{
            const hash=createsign(accionesposibles["LoginPass"],data,who);
            console.log(hash);

            if(hash == sign){
                newtoken(response,data.user,data.password).catch(error=>console.log(error));
            }
            else{
                response.status(404).json({ error: 'Sign Error'});
            }
        }
    },

    GetInformation : function (response,data,who,sign){
        console.log("GetInformation");
        //every interface
        if(!(who.toString() in Important.programwho)){response.status(400).json({ error: 'Who are you?'});}
        else{
            const hash=createsign(accionesposibles["GetInformation"],data,who);
            console.log(hash);

            if(hash == sign){
                getinformation(response,data.token).catch(error=>console.log(error));
            }
            else{
                response.status(404).json({ error: 'Sign Error'});
            }
        }
    },

    ChangePassword : function (response,data,who,sign){
        console.log("ChangePassword");
        //only web/php
        if(who != Important.Programwho[0]){response.status(400).json({ error: 'Who are you?'});}
        else{
            const hash=createsign(accionesposibles["ChangePassword"],data,who);
            console.log(hash);
            if(hash==sign){
                newpassword(response,data.user,data.oldpassword,data.newpassword);
            }
            else{
                response.status(404).json({ error: 'Sign Error'});
            }
        }
    },

    ChangeMobil : function (response,data,who,sign){
        console.log("ChangeMobil");
        //only web/php
        if(who != Important.Programwho[0]){response.status(400).json({ error: 'Who are you?'});}
        else{
            const hash=createsign(accionesposibles["ChangeMobil"],data,who);
            console.log(hash);
            if(hash==sign){
                changemobilnumber(response,data.token,data.number);
            }
            else{
                response.status(404).json({ error: 'Sign Error'});
            }
        }
    },

    ValidateMobil : function (response,data,who,sign){
        console.log("ValidateMobil");
        //only web/php
        if(who != Important.Programwho[0]){response.status(400).json({ error: 'Who are you?'});}
        else{
            const hash=createsign(accionesposibles["ValidateMobil"],data,who);
            console.log(hash);
            if(hash==sign){
                validatemobilnumber(response,data.token,data.code);
            }
            else{
                response.status(404).json({ error: 'Sign Error'});
            }
        }
    }
};


/*
DONE
ChangeMobil (token,number) -> true
13:56
2. ValidateMobil (token, code) -> true
13:57

TODO
3. ChangeLocation(token, CountryNumber, City) donde city puede estar vacio
13:59
4. ChangeWallet (user, password) -> true
13:59
5. ValidateChangeWallet (user, code)
14:00
6. ChangeAvatar (token, avatar)
14:00
7. RestorePassword (user)
14:00
8. RestorePasswordCode(user,password,code)
*/



